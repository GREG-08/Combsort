package combsort;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.Random;
import javax.swing.*;
import javax.swing.plaf.basic.BasicOptionPaneUI;

// главное окно
public class SimpleGUI extends JFrame {

    private JButton button = new JButton("Получить отсортированный массив");

    private JTextField input = new JTextField("", 2);
    private JTextField input2 = new JTextField("", 5);
    private JTextField input3 = new JTextField("", 5);
    private JTextField input4 = new JTextField("", 5);
    private JTextField input5 = new JTextField("", 5);

    private JLabel label = new JLabel("Введите 1-ое целое число массива:");
    private JLabel label2 = new JLabel("Введите 2-ое целое число массива:");
    private JLabel label3 = new JLabel("Введите 3-е целое число массива:");
    private JLabel label4 = new JLabel("Введите 4-ое целое число массива:");
    private JLabel label5 = new JLabel("Введите 5-ое целое число массива:");
    JLabel label0 = new JLabel();
    JLabel label9 = new JLabel();
    JRadioButton radio1 = new JRadioButton("Сортировка методом Combsort");
    JRadioButton radio2 = new JRadioButton("Сортировка методом Bogosort");
    private static final Random generator = new Random();


    //контейнер
    public SimpleGUI() {
        super("ПРОГРАММА СОРТИРОВКИ МАССИВА");
        this.setBounds(100, 100, 600, 250);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container container = this.getContentPane();
        container.setLayout(new GridLayout(8, 4, 4, 1));
        container.add(label);
        container.add(input);
        container.add(label2);
        container.add(input2);
        container.add(label3);
        container.add(input3);
        container.add(label4);
        container.add(input4);
        container.add(label5);
        container.add(input5);
        // Кнопки переключения
        ButtonGroup group = new ButtonGroup();
        group.add(radio1);
        group.add(radio2);
        container.add(radio1);
        radio1.setSelected(false);
        container.add(radio2);


        //конец
//главная кнопка
        button.addActionListener(new ButtonEventListener());
        container.add(button);
        container.add(label0);
        container.add(label9);

    }

    //слушатель 
    class ButtonEventListener implements ActionListener {
        public void actionPerformed(ActionEvent event) {

            if (radio1.isSelected()) ;
            {
//объявлем переменные
                int a = 0, b = 0, c = 0, d = 0, e = 0;
                try {
                    a = Integer.parseInt(input.getText());
                    b = Integer.parseInt(input2.getText());
                    c = Integer.parseInt(input3.getText());
                    d = Integer.parseInt(input4.getText());
                    e = Integer.parseInt(input5.getText());
                } catch (Exception er) {
                    JOptionPane.showMessageDialog(null, "В поле введенно не коректное значение");
                }

                int[] array = new int[]{a, b, c, d, e};
                combSort(array);
                label0.setText(Arrays.toString(array) + "");//вывод в label готового массива



            }

            if (radio2.isSelected()) ;
            {
                int l = 0, m = 0, n = 0, p = 0, q = 0;
                l = Integer.parseInt(input.getText());
                m = Integer.parseInt(input2.getText());
                n = Integer.parseInt(input3.getText());
                p = Integer.parseInt(input4.getText());
                q = Integer.parseInt(input5.getText());
                //метод Bogosort

                int[] array1 = new int[]{l, m, n, p, q};
                bogoSort(array1);
                label9.setText(Arrays.toString(array1) + "");

            }











        }
    }
    //метод combsort
    public static void combSort ( int[] array){
        int step = (int) (array.length / 1.247);
        int swapCount = 1;
        for (; step > 1 || swapCount > 0; ) {
            swapCount = 0;
            for (int i = 0; i + step < array.length; i++) {
                if (array[i] > array[i + step]) {
                    int temp = array[i];
                    array[i] = array[i + step];
                    array[i + step] = temp;
                    swapCount++;
                }
            }
            if (step > 1) {
                step = (int) (step / 1.247);
            }
        }
    }

//метод bogosort

    public static void bogoSort(int[] array1) {
        while (!isSorted(array1)) {
            for (int i = 0; i < array1.length; i++) {
                int randomPosition = generator.nextInt(array1.length);
                int temp = array1[i];
                array1[i] = array1[randomPosition];
                array1[randomPosition] = temp;
            }
        }
    }

    private static boolean isSorted(int[] array) {
        for (int i = 1; i < array.length; i++) {
            if (array[i] < array[i - 1]) {
                return false;
            }
        }
        return true;
    }


}