package combsort;

import java.util.Arrays;
import java.util.Scanner;



//главный класс
public class Main {

    public static void main(String[] args) {
        SimpleGUI app = new SimpleGUI();// подключили класс SimpleGUI
        app.setVisible(true);
        // TODO Auto-generated method stub

    }


}
